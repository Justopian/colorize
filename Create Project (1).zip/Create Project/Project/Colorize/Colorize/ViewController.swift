//
//  ViewController.swift
//  Colorize
//

import UIKit

class ViewController: UIViewController
{

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        resetApp()
    }
    
    @IBOutlet weak var targetColorLabel: UILabel!
    @IBOutlet weak var paletteColorLabel: UILabel!
    @IBOutlet weak var randomLabel: UILabel!
    @IBOutlet weak var matchesLabel: UILabel!
    @IBOutlet weak var operationCountLabel: UILabel!
    @IBOutlet weak var attemptCountLabel: UILabel!
    @IBOutlet weak var difficultyLabel: UILabel!
    @IBOutlet weak var operationSegmentControl: UISegmentedControl!
    
    var operationCount = 0
    var matchCount = 0
    var attemptCount = 0
    
    var difficulty = 3
    var componentMaxValue = 15
    
    func convertToDub(_ number:Int) -> Double
    {
        return Double(number) / Double(componentMaxValue)
    }
    
    func randomColor(_ allowZero:Bool = true) -> Int
    {
        print("randomColor() initialized")
        
        var randomInt:Int
        var lowerBound:Int
        
        if allowZero || difficulty == 0
        {
            lowerBound = 0
        }
        else
        {
            lowerBound = 1
        }
        
        randomInt = Int.random(in: lowerBound...componentMaxValue)
        
        return randomInt
    }
    
    func colorize(label:UILabel!)
    {
        var unconvertedRGB = deconstructRGB(label.text!)
        var convertedRGB:[CGFloat] = [0.0, 0.0, 0.0]
        var negativeRGB:[CGFloat] = [0.0, 0.0, 0.0]
        
        for component in 0..<unconvertedRGB.count
        {
            convertedRGB[component] = CGFloat(convertToDub(unconvertedRGB[component]))
            negativeRGB[component] = 1.0 - convertedRGB[component]
        }
        
        label.backgroundColor = UIColor.init(red: convertedRGB[0], green: convertedRGB[1], blue: convertedRGB[2], alpha: 1.0)
        
        label.textColor = UIColor.init(red: negativeRGB[0], green: negativeRGB[1], blue: negativeRGB[2], alpha: 1.0)
        
        if label.backgroundColor == label.textColor
        { // 50% Gray
            label.textColor = UIColor.white
        }
    }
    
    func deconstructRGB(_ text:String) -> [Int]
    {
        let firstSpace = text.firstIndex(of: Character.init(" "))!
        let firstComma = text.firstIndex(of: Character.init(","))!
        let lastSpace = text.lastIndex(of: Character.init(" "))!
        let lastComma = text.lastIndex(of:Character.init(","))!
        
        let ranges = [
            text.index(after: text.startIndex)..<firstComma,
            text.index(after: firstSpace)..<lastComma,
            text.index(after: lastSpace)..<text.index(before: text.endIndex)
        ]
        
        var rgbValues:[Int] = [0, 0, 0]
        for index in 0..<ranges.count
        {
            rgbValues[index] += Int("\(text[ranges[index]])") ?? 0
        }
        
        return rgbValues
    }
    
    func resetApp()
    {
        // Reset Target Color Label
        repeat {
            var randomComponents:[Int] = [0, 0, 0]
            for component in 0..<randomComponents.count
            {
                randomComponents[component] = randomColor()
            }
            targetColorLabel.text = "(\(randomComponents[0]), \(randomComponents[1]), \(randomComponents[2]))"
        } while targetColorLabel.backgroundColor == UIColor.black
        
        colorize(label: targetColorLabel)
        
        // Reset Palette Color Label
        paletteColorLabel.text = "(0, 0, 0)"
        colorize(label: paletteColorLabel)
        
        // Update Bit Label
        randomLabel.text = "\(randomColor(false))"
        operationCount = 0
        operationCountLabel.text = "Operations Done: \(operationCount)"
        
        operationSegmentControl.selectedSegmentIndex = 0
        
        // Update Attempt Label
        attemptCount += 1
        attemptCountLabel.text = "Attempt #\(attemptCount)"
    }
    
    @IBAction func userControlSegments(_ sender: UISegmentedControl)
    {
        let selectedSegment = sender.selectedSegmentIndex
        let mixedRGBText = paletteColorLabel.text!
        var mixedRGBValues = deconstructRGB(mixedRGBText)
        
        switch operationSegmentControl.selectedSegmentIndex {
        case 0: // Addition Operator
            mixedRGBValues[selectedSegment] += Int(randomLabel.text ?? "0") ?? 0
            mixedRGBValues[selectedSegment] %= componentMaxValue + 1
        case 1: // Subtraction Operator
            mixedRGBValues[selectedSegment] -= Int(randomLabel.text ?? "0") ?? 0
            while mixedRGBValues[selectedSegment] < 0
            {
                mixedRGBValues[selectedSegment] += componentMaxValue
            }
        default: // Error
            print("Operation Index Not Found")
        }
        
        paletteColorLabel.text = "(\(mixedRGBValues[0]), \(mixedRGBValues[1]), \(mixedRGBValues[2]))"
        colorize(label: paletteColorLabel)
        
        randomLabel.text = "\(randomColor(false))"
        operationCount += 1
        operationCountLabel.text = "Operations Done: \(operationCount)"
        
        if targetColorLabel.text! == paletteColorLabel.text!
        {
            matchCount += 1
            matchesLabel.text = "Matches: \(matchCount)"
            resetApp()
        }
    }

    @IBAction func changeDifficulty(_ sender: UIStepper)
    {
        difficulty = Int(sender.value)
 
        componentMaxValue = 1
        for _ in 0...difficulty
        {
            componentMaxValue *= 2
        }
        componentMaxValue -= 1
        
        difficultyLabel.text = "Difficulty: \(difficulty)"
        
        resetApp()
    }
    
    @IBAction func restart(_ sender: Any)
    {
        resetApp()
    }
    
}
